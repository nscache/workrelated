//
//  FullSingleton.h
//  HungryBear
//
//  Created by Bruce Yang on 12-2-23.
//  Copyright (c) 2012年 EricGameStudio. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FullSingleton : NSObject {
    
}

+(FullSingleton *) getInstance;

@end
